var Task = function(){
    this.taskName='';
    this.done = false;
    this.taskID = ''
 }
 
 var taskList = [
     {taskID:1,taskName:'task1',done:false },
     {taskID:2,taskName:'task2',done:false },
     {taskID:3,taskName:'task3',done:false }
 ]