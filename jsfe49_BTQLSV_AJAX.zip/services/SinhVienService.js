var SinhVienService = function () {
    this.xoaSinhVien = function (maSV) {
        return axios({
            url:'http://svcy.myclass.vn/api/SinhVien/XoaSinhVien/' + maSV,
            method:'DELETE'
        }) 
    }
}